'use strict';

/*
  ESTRATEGIA DE DISEÑO — Color Connect
  ════════════════════════════════════════════════════════════════
  Cada nivel fue diseñado así:
    1. Se traza la solución completa primero: TODAS las celdas del
       tablero quedan asignadas a exactamente un color.
    2. Los extremos de cada ruta son los "puntos" (dots) visibles.
    3. El camino corto entre dos puntos siempre deja celdas sin
       cubrir que son necesarias para otro color → el jugador DEBE
       encontrar el camino largo correcto.
    4. La condición de victoria exige tablero 100% cubierto.

  N1 · 5×5 · 4 colores · 25/25 celdas  (fácil)
  N2 · 6×6 · 4 colores · 36/36 celdas  (medio)
  N3 · 7×7 · 4 colores · 49/49 celdas  (medio-difícil)
  N4 · 7×7 · 5 colores · 49/49 celdas  (difícil)
  N5 · 8×8 · 4 colores · 64/64 celdas  (muy difícil)
*/

const COLORS = {
  red:    { fill: '#FF1744', glow: '#FF6E6E', light: '#FF8A80', dark: '#C62828', stroke: '#B71C1C' },
  blue:   { fill: '#2979FF', glow: '#82B1FF', light: '#BBDEFB', dark: '#0D47A1', stroke: '#0D47A1' },
  yellow: { fill: '#FFD600', glow: '#FFEE58', light: '#FFFF8D', dark: '#F57F17', stroke: '#F57F17' },
  green:  { fill: '#00E676', glow: '#69FF47', light: '#B9F6CA', dark: '#00600F', stroke: '#1B5E20' },
  orange: { fill: '#FF6D00', glow: '#FFAB40', light: '#FFCC80', dark: '#BF360C', stroke: '#E65100' },
  purple: { fill: '#D500F9', glow: '#EA80FC', light: '#F3B8FF', dark: '#4A148C', stroke: '#6A1B9A' },
  teal:   { fill: '#00E5FF', glow: '#84FFFF', light: '#B2FFFF', dark: '#004D40', stroke: '#006064' },
};

const LEVELS = [

  /* ════════════════════════════════════════════════════════════════
     NIVEL 1 · 5×5 · 4 colores · 25/25 celdas
     Mapa de solución:
       R R R R R   fila 0
       B G G G R   fila 1
       B Y Y G R   fila 2
       B Y Y G R   fila 3
       B B B G R   fila 4
     Trampa: Yellow parece unirse en 2 pasos (2,1)→(3,1), pero
     dejaría (2,2) y (3,2) sin cubrir — green no puede pasar ahí.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 1',
    difficulty: 'easy',
    grid: 5,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 4, col: 4 },
      { color: 'blue',   row: 1, col: 0 },
      { color: 'blue',   row: 4, col: 2 },
      { color: 'green',  row: 1, col: 1 },
      { color: 'green',  row: 4, col: 3 },
      { color: 'yellow', row: 2, col: 1 },
      { color: 'yellow', row: 3, col: 1 },
    ],
    hintColor: 'yellow',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},
               {row:1,col:4},{row:2,col:4},{row:3,col:4},{row:4,col:4}],
      blue:   [{row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2}],
      green:  [{row:1,col:1},{row:1,col:2},{row:1,col:3},{row:2,col:3},{row:3,col:3},{row:4,col:3}],
      yellow: [{row:2,col:1},{row:2,col:2},{row:3,col:2},{row:3,col:1}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 2 · 6×6 · 4 colores · 36/36 celdas
     Mapa de solución:
       R R R R R R   fila 0
       B B B B B R   fila 1
       B Y Y Y Y R   fila 2
       B G G G Y R   fila 3
       B G G G Y R   fila 4
       B B B B R R   fila 5
     Trampa: Green parece unirse en 2 pasos (3,1)→(4,1), pero
     dejaría (3,2)(3,3)(4,2)(4,3) sin cubrir — nadie más pasa ahí.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 2',
    difficulty: 'easy',
    grid: 6,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 5, col: 4 },
      { color: 'blue',   row: 5, col: 3 },
      { color: 'blue',   row: 1, col: 4 },
      { color: 'yellow', row: 2, col: 1 },
      { color: 'yellow', row: 4, col: 4 },
      { color: 'green',  row: 3, col: 1 },
      { color: 'green',  row: 4, col: 1 },
    ],
    hintColor: 'green',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},
               {row:1,col:5},{row:2,col:5},{row:3,col:5},{row:4,col:5},{row:5,col:5},{row:5,col:4}],
      blue:   [{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0},{row:4,col:0},{row:3,col:0},
               {row:2,col:0},{row:1,col:0},{row:1,col:1},{row:1,col:2},{row:1,col:3},{row:1,col:4}],
      yellow: [{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:3,col:4},{row:4,col:4}],
      green:  [{row:3,col:1},{row:3,col:2},{row:3,col:3},{row:4,col:3},{row:4,col:2},{row:4,col:1}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 3 · 7×7 · 4 colores · 49/49 celdas
     Mapa de solución:
       R R R R R R R   fila 0
       B B B B B B R   fila 1
       B Y Y Y Y Y R   fila 2
       B Y G G G Y R   fila 3
       B Y G G G Y R   fila 4
       B Y Y Y Y Y R   fila 5
       B B B B R R R   fila 6
     Trampa: Y(2,1)→(5,1) parece un camino recto ↓ pero (3,1) y
     (4,1) ya pertenecen a Y via su ruta larga; ir directo no llena
     el marco interno. G(3,2)→(4,2) son adyacentes pero la ruta
     recta deja (3,3)(3,4)(4,3)(4,4) sin cubrir.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 3',
    difficulty: 'medium',
    grid: 7,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 6, col: 4 },
      { color: 'blue',   row: 6, col: 3 },
      { color: 'blue',   row: 1, col: 5 },
      { color: 'yellow', row: 2, col: 1 },
      { color: 'yellow', row: 5, col: 1 },
      { color: 'green',  row: 3, col: 2 },
      { color: 'green',  row: 4, col: 2 },
    ],
    hintColor: 'yellow',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},
               {row:1,col:6},{row:2,col:6},{row:3,col:6},{row:4,col:6},{row:5,col:6},{row:6,col:6},{row:6,col:5},{row:6,col:4}],
      blue:   [{row:6,col:3},{row:6,col:2},{row:6,col:1},{row:6,col:0},{row:5,col:0},{row:4,col:0},{row:3,col:0},
               {row:2,col:0},{row:1,col:0},{row:1,col:1},{row:1,col:2},{row:1,col:3},{row:1,col:4},{row:1,col:5}],
      yellow: [{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5},
               {row:3,col:5},{row:4,col:5},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1}],
      green:  [{row:3,col:2},{row:3,col:3},{row:3,col:4},{row:4,col:4},{row:4,col:3},{row:4,col:2}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 4 · 7×7 · 5 colores · 49/49 celdas
     Mapa de solución:
       R R R R R R R   fila 0
       Y Y Y Y Y Y R   fila 1
       O O O G G Y R   fila 2
       O O O G G Y R   fila 3
       O O O O G Y B   fila 4
       Y Y Y Y Y Y B   fila 5
       B B B B B B B   fila 6
     Orange cubre el bloque izquierdo interior (cols 0-3, filas 2-4).
     Trampa O: (3,1)→(4,3) parece ruta corta pero (4,0)(3,0)(2,0)
     etc. quedarían sin cubrir — nadie más pasa por ahí.
     Trampa G: (2,3)→(4,4) parece largo pero (3,3)→(4,3) está
     bloqueado por orange → debe ir por (2,3)→(3,3)... ✓
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 4',
    difficulty: 'hard',
    grid: 7,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 4, col: 6 },
      { color: 'blue',   row: 5, col: 6 },
      { color: 'blue',   row: 6, col: 0 },
      { color: 'yellow', row: 1, col: 0 },
      { color: 'yellow', row: 5, col: 0 },
      { color: 'green',  row: 2, col: 4 },
      { color: 'green',  row: 4, col: 4 },
      { color: 'orange', row: 3, col: 1 },
      { color: 'orange', row: 4, col: 3 },
    ],
    hintColor: 'orange',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},
               {row:1,col:6},{row:2,col:6},{row:3,col:6},{row:4,col:6}],
      blue:   [{row:5,col:6},{row:6,col:6},{row:6,col:5},{row:6,col:4},{row:6,col:3},{row:6,col:2},{row:6,col:1},{row:6,col:0}],
      yellow: [{row:1,col:0},{row:1,col:1},{row:1,col:2},{row:1,col:3},{row:1,col:4},{row:1,col:5},
               {row:2,col:5},{row:3,col:5},{row:4,col:5},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0}],
      green:  [{row:2,col:4},{row:2,col:3},{row:3,col:3},{row:3,col:4},{row:4,col:4}],
      orange: [{row:3,col:1},{row:4,col:1},{row:4,col:0},{row:3,col:0},{row:2,col:0},{row:2,col:1},{row:2,col:2},{row:3,col:2},{row:4,col:2},{row:4,col:3}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 5 · 8×8 · 4 colores · 64/64 celdas
     R ocupa fila 0 completa, B fila 7 completa.
     Y serpentea por cols 0-3 (filas 1-6): 24 celdas.
     G serpentea por cols 4-7 (filas 1-6): 24 celdas.
     Trampa: Y(1,0)→(1,3) parece un camino de 4 celdas ↔ pero deja
     todo el interior izquierdo (filas 2-6) sin cubrir — imposible
     de ganar sin el serpenteo completo.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 5',
    difficulty: 'expert',
    grid: 8,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 0, col: 7 },
      { color: 'blue',   row: 7, col: 0 },
      { color: 'blue',   row: 7, col: 7 },
      { color: 'yellow', row: 1, col: 0 },
      { color: 'yellow', row: 1, col: 3 },
      { color: 'green',  row: 1, col: 7 },
      { color: 'green',  row: 1, col: 4 },
    ],
    hintColor: 'green',
    solution: {
      red:  [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},
             {row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7}],
      blue: [{row:7,col:0},{row:7,col:1},{row:7,col:2},{row:7,col:3},
             {row:7,col:4},{row:7,col:5},{row:7,col:6},{row:7,col:7}],
      yellow: [
        {row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},{row:5,col:0},{row:6,col:0},
        {row:6,col:1},{row:5,col:1},{row:4,col:1},{row:3,col:1},{row:2,col:1},{row:1,col:1},
        {row:1,col:2},{row:2,col:2},{row:3,col:2},{row:4,col:2},{row:5,col:2},{row:6,col:2},
        {row:6,col:3},{row:5,col:3},{row:4,col:3},{row:3,col:3},{row:2,col:3},{row:1,col:3},
      ],
      green: [
        {row:1,col:7},{row:2,col:7},{row:3,col:7},{row:4,col:7},{row:5,col:7},{row:6,col:7},
        {row:6,col:6},{row:5,col:6},{row:4,col:6},{row:3,col:6},{row:2,col:6},{row:1,col:6},
        {row:1,col:5},{row:2,col:5},{row:3,col:5},{row:4,col:5},{row:5,col:5},{row:6,col:5},
        {row:6,col:4},{row:5,col:4},{row:4,col:4},{row:3,col:4},{row:2,col:4},{row:1,col:4},
      ],
    },
  },


  /* ════════════════════════════════════════════════════════════════
     NIVEL 6 · 6×6 · 5 colores · 36/36 celdas  (medio)
     Mapa:
       R R R R R R   fila 0
       Y G G G G B   fila 1
       Y O O O G B   fila 2
       Y O O O G B   fila 3
       Y Y Y Y Y B   fila 4
       B B B B B B   fila 5
     Trampa Orange: (2,1)↔(3,1) son adyacentes, unión directa deja
     (2,2)(2,3)(3,2)(3,3) sin cubrir — nadie más puede pasar ahí.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 6',
    difficulty: 'medium',
    grid: 6,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 0, col: 5 },
      { color: 'blue',   row: 1, col: 5 },
      { color: 'blue',   row: 5, col: 0 },
      { color: 'yellow', row: 1, col: 0 },
      { color: 'yellow', row: 4, col: 4 },
      { color: 'green',  row: 1, col: 1 },
      { color: 'green',  row: 3, col: 4 },
      { color: 'orange', row: 2, col: 1 },
      { color: 'orange', row: 3, col: 1 },
    ],
    hintColor: 'orange',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5}],
      blue:   [{row:1,col:5},{row:2,col:5},{row:3,col:5},{row:4,col:5},{row:5,col:5},
               {row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0}],
      yellow: [{row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},
               {row:4,col:1},{row:4,col:2},{row:4,col:3},{row:4,col:4}],
      green:  [{row:1,col:1},{row:1,col:2},{row:1,col:3},{row:1,col:4},{row:2,col:4},{row:3,col:4}],
      orange: [{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:3,col:3},{row:3,col:2},{row:3,col:1}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 7 · 7×7 · 5 colores · 49/49 celdas  (medio)
     Mapa:
       R R R R R R R   fila 0
       B Y Y G G G R   fila 1
       B Y Y O O G R   fila 2
       B Y Y O O G R   fila 3
       B Y Y O G G R   fila 4
       B Y Y O G G R   fila 5
       B B B B B B R   fila 6
     Trampa Yellow: (1,1)↔(1,2) adyacentes, unión directa deja toda
     la columna Y×2 (filas 2-5) sin cubrir.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 7',
    difficulty: 'medium',
    grid: 7,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 6, col: 6 },
      { color: 'blue',   row: 1, col: 0 },
      { color: 'blue',   row: 6, col: 5 },
      { color: 'yellow', row: 1, col: 1 },
      { color: 'yellow', row: 1, col: 2 },
      { color: 'green',  row: 1, col: 3 },
      { color: 'green',  row: 4, col: 4 },
      { color: 'orange', row: 2, col: 3 },
      { color: 'orange', row: 5, col: 3 },
    ],
    hintColor: 'yellow',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},
               {row:1,col:6},{row:2,col:6},{row:3,col:6},{row:4,col:6},{row:5,col:6},{row:6,col:6}],
      blue:   [{row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},{row:5,col:0},
               {row:6,col:0},{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4},{row:6,col:5}],
      yellow: [{row:1,col:1},{row:2,col:1},{row:3,col:1},{row:4,col:1},{row:5,col:1},
               {row:5,col:2},{row:4,col:2},{row:3,col:2},{row:2,col:2},{row:1,col:2}],
      green:  [{row:1,col:3},{row:1,col:4},{row:1,col:5},{row:2,col:5},{row:3,col:5},
               {row:4,col:5},{row:5,col:5},{row:5,col:4},{row:4,col:4}],
      orange: [{row:2,col:3},{row:2,col:4},{row:3,col:4},{row:3,col:3},{row:4,col:3},{row:5,col:3}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 8 · 8×8 · 5 colores · 64/64 celdas  (difícil)
     Mapa:
       R R R R R R R R   fila 0
       B Y Y G G O O R   fila 1
       B Y Y G G O O R   fila 2  (hasta fila 6, mismo patrón)
       ...
       B Y Y G G O O R   fila 6
       B B B B B B B R   fila 7
     Trampa TRIPLE: los 3 colores interiores tienen sus puntos
     adyacentes en fila 1 — unir directo deja 5 filas sin cubrir.
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 8',
    difficulty: 'hard',
    grid: 8,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 7, col: 7 },
      { color: 'blue',   row: 1, col: 0 },
      { color: 'blue',   row: 7, col: 6 },
      { color: 'yellow', row: 1, col: 1 },
      { color: 'yellow', row: 1, col: 2 },
      { color: 'green',  row: 1, col: 3 },
      { color: 'green',  row: 1, col: 4 },
      { color: 'orange', row: 1, col: 5 },
      { color: 'orange', row: 1, col: 6 },
    ],
    hintColor: 'green',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},
               {row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7},
               {row:1,col:7},{row:2,col:7},{row:3,col:7},{row:4,col:7},
               {row:5,col:7},{row:6,col:7},{row:7,col:7}],
      blue:   [{row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},
               {row:5,col:0},{row:6,col:0},{row:7,col:0},{row:7,col:1},
               {row:7,col:2},{row:7,col:3},{row:7,col:4},{row:7,col:5},{row:7,col:6}],
      yellow: [{row:1,col:1},{row:2,col:1},{row:3,col:1},{row:4,col:1},
               {row:5,col:1},{row:6,col:1},{row:6,col:2},{row:5,col:2},
               {row:4,col:2},{row:3,col:2},{row:2,col:2},{row:1,col:2}],
      green:  [{row:1,col:3},{row:2,col:3},{row:3,col:3},{row:4,col:3},
               {row:5,col:3},{row:6,col:3},{row:6,col:4},{row:5,col:4},
               {row:4,col:4},{row:3,col:4},{row:2,col:4},{row:1,col:4}],
      orange: [{row:1,col:5},{row:2,col:5},{row:3,col:5},{row:4,col:5},
               {row:5,col:5},{row:6,col:5},{row:6,col:6},{row:5,col:6},
               {row:4,col:6},{row:3,col:6},{row:2,col:6},{row:1,col:6}],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 9 · 8×8 · 5 colores · 64/64 celdas  (difícil)
     Mapa:
       R R R R R R R R   fila 0
       Y Y Y G G O O O   fila 1
       Y Y Y G G O O O   fila 2
       Y Y Y G G O O O   fila 3
       Y Y Y G G O O O   fila 4
       Y Y G G G G O O   fila 5
       Y Y G G G G O O   fila 6
       B B B B B B B B   fila 7
     Trampa Orange: (1,5)↔(4,5) parecen cercanos, unión directa en
     col 5 deja cols 6-7 sin cubrir (14 celdas huérfanas).
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 9',
    difficulty: 'hard',
    grid: 8,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 0, col: 7 },
      { color: 'blue',   row: 7, col: 0 },
      { color: 'blue',   row: 7, col: 7 },
      { color: 'yellow', row: 1, col: 0 },
      { color: 'yellow', row: 4, col: 2 },
      { color: 'green',  row: 5, col: 2 },
      { color: 'green',  row: 5, col: 5 },
      { color: 'orange', row: 1, col: 5 },
      { color: 'orange', row: 4, col: 5 },
    ],
    hintColor: 'orange',
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},
               {row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7}],
      blue:   [{row:7,col:0},{row:7,col:1},{row:7,col:2},{row:7,col:3},
               {row:7,col:4},{row:7,col:5},{row:7,col:6},{row:7,col:7}],
      yellow: [
        {row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},{row:5,col:0},{row:6,col:0},
        {row:6,col:1},{row:5,col:1},{row:4,col:1},{row:3,col:1},{row:2,col:1},{row:1,col:1},
        {row:1,col:2},{row:2,col:2},{row:3,col:2},{row:4,col:2},
      ],
      green: [
        {row:5,col:2},{row:6,col:2},{row:6,col:3},{row:5,col:3},{row:4,col:3},{row:3,col:3},
        {row:2,col:3},{row:1,col:3},{row:1,col:4},{row:2,col:4},{row:3,col:4},{row:4,col:4},
        {row:5,col:4},{row:6,col:4},{row:6,col:5},{row:5,col:5},
      ],
      orange: [
        {row:1,col:5},{row:1,col:6},{row:1,col:7},{row:2,col:7},{row:3,col:7},{row:4,col:7},
        {row:5,col:7},{row:6,col:7},{row:6,col:6},{row:5,col:6},{row:4,col:6},{row:3,col:6},
        {row:2,col:6},{row:2,col:5},{row:3,col:5},{row:4,col:5},
      ],
    },
  },

  /* ════════════════════════════════════════════════════════════════
     NIVEL 10 · 9×9 · 5 colores · 81/81 celdas  (experto)
     Mapa (filas 1-7 = 3 columnas cada color):
       R R R R R R R R R   fila 0
       Y Y Y G G G O O O   fila 1-7 (serpentín de 3 cols × 7 filas)
       B B B B B B B B B   fila 8
     Yellow serpentea cols 0-2, Green cols 3-5, Orange cols 6-8.
     Trampa: intentar unir Yellow en línea recta ↓col0 deja
     cols 1-2 de filas 2-7 sin cubrir (12 celdas huérfanas).
  ════════════════════════════════════════════════════════════════ */
  {
    title: 'Nivel 10',
    difficulty: 'expert',
    grid: 9,
    dots: [
      { color: 'red',    row: 0, col: 0 },
      { color: 'red',    row: 0, col: 8 },
      { color: 'blue',   row: 8, col: 0 },
      { color: 'blue',   row: 8, col: 8 },
      { color: 'yellow', row: 1, col: 0 },
      { color: 'yellow', row: 7, col: 2 },
      { color: 'green',  row: 7, col: 3 },
      { color: 'green',  row: 1, col: 5 },
      { color: 'orange', row: 1, col: 6 },
      { color: 'orange', row: 7, col: 8 },
    ],
    hintColor: 'yellow',
    solution: {
      red:  [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},
             {row:0,col:5},{row:0,col:6},{row:0,col:7},{row:0,col:8}],
      blue: [{row:8,col:0},{row:8,col:1},{row:8,col:2},{row:8,col:3},{row:8,col:4},
             {row:8,col:5},{row:8,col:6},{row:8,col:7},{row:8,col:8}],
      yellow: [
        {row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},{row:5,col:0},{row:6,col:0},{row:7,col:0},
        {row:7,col:1},{row:6,col:1},{row:5,col:1},{row:4,col:1},{row:3,col:1},{row:2,col:1},{row:1,col:1},
        {row:1,col:2},{row:2,col:2},{row:3,col:2},{row:4,col:2},{row:5,col:2},{row:6,col:2},{row:7,col:2},
      ],
      green: [
        {row:7,col:3},{row:6,col:3},{row:5,col:3},{row:4,col:3},{row:3,col:3},{row:2,col:3},{row:1,col:3},
        {row:1,col:4},{row:2,col:4},{row:3,col:4},{row:4,col:4},{row:5,col:4},{row:6,col:4},{row:7,col:4},
        {row:7,col:5},{row:6,col:5},{row:5,col:5},{row:4,col:5},{row:3,col:5},{row:2,col:5},{row:1,col:5},
      ],
      orange: [
        {row:1,col:6},{row:2,col:6},{row:3,col:6},{row:4,col:6},{row:5,col:6},{row:6,col:6},{row:7,col:6},
        {row:7,col:7},{row:6,col:7},{row:5,col:7},{row:4,col:7},{row:3,col:7},{row:2,col:7},{row:1,col:7},
        {row:1,col:8},{row:2,col:8},{row:3,col:8},{row:4,col:8},{row:5,col:8},{row:6,col:8},{row:7,col:8},
      ],
    },
  },

  // ── N12 · 5×5 · 4 colores · 25/25  (fácil) ──────────────────────────────
  {
    title:'Nivel 12', grid:5, difficulty:'easy', hintColor:'green',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:4},
      {color:'blue',  row:1,col:3},{color:'blue',  row:2,col:1},
      {color:'yellow',row:2,col:2},{color:'yellow',row:3,col:2},
      {color:'green', row:3,col:1},{color:'green', row:4,col:4},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:1,col:4}],
      blue:  [{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1}],
      yellow:[{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:3,col:4},{row:3,col:3},{row:3,col:2}],
      green: [{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2},{row:4,col:3},{row:4,col:4}],
    },
  },

  // ── N13 · 5×5 · 4 colores · 25/25  (fácil) ──────────────────────────────
  {
    title:'Nivel 13', grid:5, difficulty:'easy', hintColor:'yellow',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:4,col:1},
      {color:'blue',  row:3,col:1},{color:'blue',  row:1,col:2},
      {color:'yellow',row:2,col:2},{color:'yellow',row:2,col:3},
      {color:'green', row:1,col:3},{color:'green', row:4,col:4},
    ],
    solution:{
      red:   [{row:0,col:0},{row:1,col:0},{row:2,col:0},{row:3,col:0},{row:4,col:0},{row:4,col:1}],
      blue:  [{row:3,col:1},{row:2,col:1},{row:1,col:1},{row:0,col:1},{row:0,col:2},{row:1,col:2}],
      yellow:[{row:2,col:2},{row:3,col:2},{row:4,col:2},{row:4,col:3},{row:3,col:3},{row:2,col:3}],
      green: [{row:1,col:3},{row:0,col:3},{row:0,col:4},{row:1,col:4},{row:2,col:4},{row:3,col:4},{row:4,col:4}],
    },
  },

  // ── N14 · 6×6 · 4 colores · 36/36  (fácil) ──────────────────────────────
  {
    title:'Nivel 14', grid:6, difficulty:'easy', hintColor:'green',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:3},
      {color:'blue',  row:1,col:2},{color:'blue',  row:2,col:5},
      {color:'yellow',row:3,col:5},{color:'yellow',row:4,col:2},
      {color:'green', row:4,col:3},{color:'green', row:5,col:0},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:1,col:5},{row:1,col:4},{row:1,col:3}],
      blue:  [{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5}],
      yellow:[{row:3,col:5},{row:3,col:4},{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2}],
      green: [{row:4,col:3},{row:4,col:4},{row:4,col:5},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0}],
    },
  },

  // ── N15 · 6×6 · 5 colores · 36/36  (normal) ─────────────────────────────
  {
    title:'Nivel 15', grid:6, difficulty:'medium', hintColor:'orange',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:5},
      {color:'blue',  row:1,col:4},{color:'blue',  row:2,col:1},
      {color:'yellow',row:2,col:2},{color:'yellow',row:3,col:3},
      {color:'green', row:3,col:2},{color:'green', row:4,col:4},
      {color:'orange',row:4,col:5},{color:'orange',row:5,col:0},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:1,col:5}],
      blue:  [{row:1,col:4},{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1}],
      yellow:[{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5},{row:3,col:5},{row:3,col:4},{row:3,col:3}],
      green: [{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2},{row:4,col:3},{row:4,col:4}],
      orange:[{row:4,col:5},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0}],
    },
  },

  // ── N16 · 7×7 · 5 colores · 49/49  (normal) ─────────────────────────────
  {
    title:'Nivel 16', grid:7, difficulty:'medium', hintColor:'green',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:4},
      {color:'blue',  row:1,col:3},{color:'blue',  row:2,col:5},
      {color:'yellow',row:2,col:6},{color:'yellow',row:4,col:1},
      {color:'green', row:4,col:2},{color:'green', row:5,col:2},
      {color:'orange',row:5,col:1},{color:'orange',row:6,col:6},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},{row:1,col:6},{row:1,col:5},{row:1,col:4}],
      blue:  [{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5}],
      yellow:[{row:2,col:6},{row:3,col:6},{row:3,col:5},{row:3,col:4},{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1}],
      green: [{row:4,col:2},{row:4,col:3},{row:4,col:4},{row:4,col:5},{row:4,col:6},{row:5,col:6},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2}],
      orange:[{row:5,col:1},{row:5,col:0},{row:6,col:0},{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4},{row:6,col:5},{row:6,col:6}],
    },
  },

  // ── N17 · 8×8 · 6 colores · 64/64  (difícil) ────────────────────────────
  {
    title:'Nivel 17', grid:8, difficulty:'hard', hintColor:'purple',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:5},
      {color:'blue',  row:1,col:4},{color:'blue',  row:2,col:5},
      {color:'yellow',row:2,col:6},{color:'yellow',row:4,col:0},
      {color:'green', row:4,col:1},{color:'green', row:5,col:4},
      {color:'orange',row:5,col:3},{color:'orange',row:6,col:5},
      {color:'purple',row:6,col:6},{color:'purple',row:7,col:0},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7},{row:1,col:7},{row:1,col:6},{row:1,col:5}],
      blue:  [{row:1,col:4},{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5}],
      yellow:[{row:2,col:6},{row:2,col:7},{row:3,col:7},{row:3,col:6},{row:3,col:5},{row:3,col:4},{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0}],
      green: [{row:4,col:1},{row:4,col:2},{row:4,col:3},{row:4,col:4},{row:4,col:5},{row:4,col:6},{row:4,col:7},{row:5,col:7},{row:5,col:6},{row:5,col:5},{row:5,col:4}],
      orange:[{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0},{row:6,col:0},{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4},{row:6,col:5}],
      purple:[{row:6,col:6},{row:6,col:7},{row:7,col:7},{row:7,col:6},{row:7,col:5},{row:7,col:4},{row:7,col:3},{row:7,col:2},{row:7,col:1},{row:7,col:0}],
    },
  },

  // ── N18 · 9×9 · 6 colores · 81/81  (muy difícil) ────────────────────────
  {
    title:'Nivel 18', grid:9, difficulty:'expert', hintColor:'purple',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:4},
      {color:'blue',  row:1,col:3},{color:'blue',  row:3,col:8},
      {color:'yellow',row:3,col:7},{color:'yellow',row:4,col:5},
      {color:'green', row:4,col:6},{color:'green', row:6,col:0},
      {color:'orange',row:6,col:1},{color:'orange',row:7,col:4},
      {color:'purple',row:7,col:3},{color:'purple',row:8,col:8},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7},{row:0,col:8},{row:1,col:8},{row:1,col:7},{row:1,col:6},{row:1,col:5},{row:1,col:4}],
      blue:  [{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5},{row:2,col:6},{row:2,col:7},{row:2,col:8},{row:3,col:8}],
      yellow:[{row:3,col:7},{row:3,col:6},{row:3,col:5},{row:3,col:4},{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2},{row:4,col:3},{row:4,col:4},{row:4,col:5}],
      green: [{row:4,col:6},{row:4,col:7},{row:4,col:8},{row:5,col:8},{row:5,col:7},{row:5,col:6},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0},{row:6,col:0}],
      orange:[{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4},{row:6,col:5},{row:6,col:6},{row:6,col:7},{row:6,col:8},{row:7,col:8},{row:7,col:7},{row:7,col:6},{row:7,col:5},{row:7,col:4}],
      purple:[{row:7,col:3},{row:7,col:2},{row:7,col:1},{row:7,col:0},{row:8,col:0},{row:8,col:1},{row:8,col:2},{row:8,col:3},{row:8,col:4},{row:8,col:5},{row:8,col:6},{row:8,col:7},{row:8,col:8}],
    },
  },

  // ── N19 · 9×9 · 7 colores · 81/81  (muy difícil) ────────────────────────
  {
    title:'Nivel 19', grid:9, difficulty:'expert', hintColor:'teal',
    dots:[
      {color:'red',   row:0,col:0},{color:'red',   row:1,col:6},
      {color:'blue',  row:1,col:5},{color:'blue',  row:2,col:5},
      {color:'yellow',row:2,col:6},{color:'yellow',row:3,col:0},
      {color:'green', row:4,col:0},{color:'green', row:5,col:6},
      {color:'orange',row:5,col:5},{color:'orange',row:6,col:4},
      {color:'purple',row:6,col:5},{color:'purple',row:7,col:2},
      {color:'teal',  row:7,col:1},{color:'teal',  row:8,col:8},
    ],
    solution:{
      red:   [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7},{row:0,col:8},{row:1,col:8},{row:1,col:7},{row:1,col:6}],
      blue:  [{row:1,col:5},{row:1,col:4},{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1},{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5}],
      yellow:[{row:2,col:6},{row:2,col:7},{row:2,col:8},{row:3,col:8},{row:3,col:7},{row:3,col:6},{row:3,col:5},{row:3,col:4},{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0}],
      green: [{row:4,col:0},{row:4,col:1},{row:4,col:2},{row:4,col:3},{row:4,col:4},{row:4,col:5},{row:4,col:6},{row:4,col:7},{row:4,col:8},{row:5,col:8},{row:5,col:7},{row:5,col:6}],
      orange:[{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2},{row:5,col:1},{row:5,col:0},{row:6,col:0},{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4}],
      purple:[{row:6,col:5},{row:6,col:6},{row:6,col:7},{row:6,col:8},{row:7,col:8},{row:7,col:7},{row:7,col:6},{row:7,col:5},{row:7,col:4},{row:7,col:3},{row:7,col:2}],
      teal:  [{row:7,col:1},{row:7,col:0},{row:8,col:0},{row:8,col:1},{row:8,col:2},{row:8,col:3},{row:8,col:4},{row:8,col:5},{row:8,col:6},{row:8,col:7},{row:8,col:8}],
    },
  },

  // ── N11 · 7×7 · 6 colores · 49/49 celdas  (difícil) ─────────────────────
  // Snake-cut: cada color sigue la serpentina boustrofedón cortada en 6 segmentos.
  // Trampa verde: puntos (3,3)↔(4,3) parecen adyacentes → camino real = 8 celdas.
  {
    title: 'Nivel 11',
    grid: 7,
    difficulty: 'hard',
    hintColor: 'purple',
    dots: [
      {color:'red',    row:0, col:0}, {color:'red',    row:1, col:6},
      {color:'blue',   row:1, col:5}, {color:'blue',   row:2, col:1},
      {color:'yellow', row:2, col:2}, {color:'yellow', row:3, col:4},
      {color:'green',  row:3, col:3}, {color:'green',  row:4, col:3},
      {color:'orange', row:4, col:4}, {color:'orange', row:5, col:2},
      {color:'purple', row:5, col:1}, {color:'purple', row:6, col:6},
    ],
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},{row:1,col:6}],
      blue:   [{row:1,col:5},{row:1,col:4},{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1}],
      yellow: [{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5},{row:2,col:6},{row:3,col:6},{row:3,col:5},{row:3,col:4}],
      green:  [{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2},{row:4,col:3}],
      orange: [{row:4,col:4},{row:4,col:5},{row:4,col:6},{row:5,col:6},{row:5,col:5},{row:5,col:4},{row:5,col:3},{row:5,col:2}],
      purple: [{row:5,col:1},{row:5,col:0},{row:6,col:0},{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4},{row:6,col:5},{row:6,col:6}],
    },
  },

  // ── N12 · 8×8 · 7 colores · 64/64 celdas  (muy difícil) ─────────────────
  // 7 colores incluyendo purple y teal. Múltiples trampas de camino corto.
  {
    title: 'Nivel 12',
    grid: 8,
    difficulty: 'expert',
    hintColor: 'teal',
    dots: [
      {color:'red',    row:0, col:0}, {color:'red',    row:1, col:7},
      {color:'blue',   row:1, col:6}, {color:'blue',   row:2, col:1},
      {color:'yellow', row:2, col:2}, {color:'yellow', row:3, col:5},
      {color:'green',  row:3, col:4}, {color:'green',  row:4, col:3},
      {color:'orange', row:4, col:4}, {color:'orange', row:5, col:3},
      {color:'purple', row:5, col:2}, {color:'purple', row:6, col:5},
      {color:'teal',   row:6, col:6}, {color:'teal',   row:7, col:0},
    ],
    solution: {
      red:    [{row:0,col:0},{row:0,col:1},{row:0,col:2},{row:0,col:3},{row:0,col:4},{row:0,col:5},{row:0,col:6},{row:0,col:7},{row:1,col:7}],
      blue:   [{row:1,col:6},{row:1,col:5},{row:1,col:4},{row:1,col:3},{row:1,col:2},{row:1,col:1},{row:1,col:0},{row:2,col:0},{row:2,col:1}],
      yellow: [{row:2,col:2},{row:2,col:3},{row:2,col:4},{row:2,col:5},{row:2,col:6},{row:2,col:7},{row:3,col:7},{row:3,col:6},{row:3,col:5}],
      green:  [{row:3,col:4},{row:3,col:3},{row:3,col:2},{row:3,col:1},{row:3,col:0},{row:4,col:0},{row:4,col:1},{row:4,col:2},{row:4,col:3}],
      orange: [{row:4,col:4},{row:4,col:5},{row:4,col:6},{row:4,col:7},{row:5,col:7},{row:5,col:6},{row:5,col:5},{row:5,col:4},{row:5,col:3}],
      purple: [{row:5,col:2},{row:5,col:1},{row:5,col:0},{row:6,col:0},{row:6,col:1},{row:6,col:2},{row:6,col:3},{row:6,col:4},{row:6,col:5}],
      teal:   [{row:6,col:6},{row:6,col:7},{row:7,col:7},{row:7,col:6},{row:7,col:5},{row:7,col:4},{row:7,col:3},{row:7,col:2},{row:7,col:1},{row:7,col:0}],
    },
  },

];
