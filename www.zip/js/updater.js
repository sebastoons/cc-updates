'use strict';

const UPDATE_CHECK_URL = 'https://gist.githubusercontent.com/sebastoons/0355eee846a9bc5c7eb2f0d712b7c7f0/raw/version.json';
const APP_VERSION = '1.3.6';

// Espera 4s al arrancar para que la red esté lista, luego verifica
(function init() {
  if (UPDATE_CHECK_URL.includes('REEMPLAZA')) return;
  setTimeout(checkForUpdate, 4000);
})();

async function checkForUpdate() {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), 12000); // timeout 12s

  try {
    const r = await fetch(UPDATE_CHECK_URL + '?_=' + Date.now(), {
      cache: 'no-store',
      signal: controller.signal,
    });
    clearTimeout(tid);
    if (!r.ok) throw new Error('HTTP ' + r.status);
    const data = await r.json();
    if (data.version && isNewer(data.version, APP_VERSION)) {
      handleUpdate(data);
    }
  } catch (e) {
    clearTimeout(tid);
    // Reintenta en 45s si fue error de red (no timeout deliberado)
    if (e.name !== 'AbortError') {
      setTimeout(checkForUpdate, 45000);
    }
  }
}

function isNewer(remote, local) {
  const r = remote.split('.').map(Number);
  const l = local.split('.').map(Number);
  for (let i = 0; i < 3; i++) {
    if ((r[i] || 0) > (l[i] || 0)) return true;
    if ((r[i] || 0) < (l[i] || 0)) return false;
  }
  return false;
}

function handleUpdate(data) {
  const isNative   = window.Capacitor?.isNativePlatform?.();
  const LiveUpdate = window.Capacitor?.Plugins?.LiveUpdate;

  if (isNative && LiveUpdate && data.bundle_url) {
    downloadLiveUpdate(data);
  } else {
    showApkBanner(data);
  }
}

async function downloadLiveUpdate(data) {
  const { LiveUpdate } = window.Capacitor.Plugins;

  // Muestra "Descargando…" de inmediato para que el usuario sepa que algo pasa
  setBannerDownloading();

  try {
    const { bundleIds } = await LiveUpdate.getBundles();

    if (!bundleIds.includes(data.version)) {
      await LiveUpdate.downloadBundle({
        url:      data.bundle_url,
        bundleId: data.version,
      });
    }

    await LiveUpdate.setNextBundle({ bundleId: data.version });
    showRestartBanner(data);

  } catch (e) {
    // Si el live update falla por cualquier razón, ofrece el APK
    showApkBanner(data);
  }
}

// ── Estados del banner ────────────────────────────────────────────────────────

let _dotInterval = null;

function _clearDots() {
  if (_dotInterval) { clearInterval(_dotInterval); _dotInterval = null; }
}

function _getBannerEls() {
  return {
    banner:     document.getElementById('update-banner'),
    label:      document.querySelector('#update-banner .update-label'),
    notesEl:    document.getElementById('update-notes'),
    installBtn: document.getElementById('btnUpdateInstall'),
    dismissBtn: document.getElementById('btnUpdateDismiss'),
  };
}

function setBannerDownloading() {
  const { banner, label, notesEl, installBtn, dismissBtn } = _getBannerEls();
  if (!banner) return;

  _clearDots();
  banner.classList.add('downloading');

  // Animación de puntos: "Descargando" → "Descargando." → ".." → "..."
  let dots = 0;
  if (label) {
    _dotInterval = setInterval(() => {
      dots = (dots + 1) % 4;
      label.textContent = 'Descargando' + '.'.repeat(dots);
    }, 500);
    label.textContent = 'Descargando';
  }

  if (notesEl)    notesEl.textContent    = 'Preparando la nueva versión…';
  if (installBtn) { installBtn.textContent = ''; installBtn.disabled = true; }
  if (dismissBtn) dismissBtn.onclick = null; // no cerrar durante descarga

  banner.classList.remove('hidden');
}

function showRestartBanner(data) {
  const { banner, label, notesEl, installBtn, dismissBtn } = _getBannerEls();
  if (!banner) return;

  _clearDots();
  banner.classList.remove('downloading');

  if (label)   label.textContent   = 'Actualización lista';
  if (notesEl) notesEl.textContent = data.notes || 'Toca Aplicar para actualizar';

  if (installBtn) {
    installBtn.textContent = 'Aplicar';
    installBtn.disabled    = false;
    installBtn.onclick     = () => window.Capacitor.Plugins.LiveUpdate.reload();
  }
  if (dismissBtn) {
    dismissBtn.onclick = () => banner.classList.add('hidden');
  }

  banner.classList.remove('hidden');
}

function showApkBanner(data) {
  const { banner, label, notesEl, installBtn, dismissBtn } = _getBannerEls();
  if (!banner) return;

  _clearDots();
  banner.classList.remove('downloading');

  if (label)   label.textContent   = 'Nueva versión';
  if (notesEl) notesEl.textContent = data.notes || 'Mejoras disponibles';

  if (installBtn) {
    installBtn.textContent = 'Instalar';
    installBtn.disabled    = false;
    installBtn.onclick     = () => { if (data.url) window.open(data.url, '_blank'); };
  }
  if (dismissBtn) {
    dismissBtn.onclick = () => banner.classList.add('hidden');
  }

  banner.classList.remove('hidden');
}
