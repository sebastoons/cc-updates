'use strict';

const TIMER_SECONDS = 120;

// Temas visuales por dificultad — oscuridad y glow escalan con el reto
const DIFF_THEMES = {
  easy:   { bg: '#122845', cell: '#1a3558', cellAlt: '#163050', glow: 0.68 },
  medium: { bg: '#10103a', cell: '#16164e', cellAlt: '#131345', glow: 0.88 },
  hard:   { bg: '#190d30', cell: '#231142', cellAlt: '#1e0e38', glow: 1.12 },
  expert: { bg: '#0d0d18', cell: '#141428', cellAlt: '#101020', glow: 1.42 },
};

const TIERS = [
  { label: 'Fácil',       color: '#43A047', levels: [0, 1, 12, 13, 14] },
  { label: 'Normal',      color: '#1E88E5', levels: [2, 5, 6, 15, 16] },
  { label: 'Difícil',     color: '#FB8C00', levels: [3, 7, 8, 10, 17] },
  { label: 'Muy Difícil', color: '#E53935', levels: [4, 9, 11, 18, 19] },
];

const progress = {
  completed: JSON.parse(localStorage.getItem('cc_completed') || '[]'),
  markDone(li) {
    if (!this.completed.includes(li)) {
      this.completed.push(li);
      localStorage.setItem('cc_completed', JSON.stringify(this.completed));
    }
  },
  isTierUnlocked(ti) {
    if (ti === 0) return true;
    return TIERS[ti - 1].levels.every(li => this.completed.includes(li));
  },
  isTierComplete(ti) {
    return TIERS[ti].levels.every(li => this.completed.includes(li));
  },
  firstPlayable(ti) {
    const lvls = TIERS[ti].levels;
    const open = lvls.filter(li => !this.completed.includes(li));
    if (open.length === 0) return lvls[0];
    // Cambia cada dia para que la primera partida no sea siempre igual
    const key = `cc_s${ti}_${new Date().toDateString()}`;
    let stored = parseInt(sessionStorage.getItem(key));
    if (isNaN(stored) || !open.includes(stored)) {
      stored = open[Math.floor(Math.random() * open.length)];
      sessionStorage.setItem(key, stored);
    }
    return stored;
  },
  tierOf(li) { return TIERS.findIndex(t => t.levels.includes(li)); },
  nextInTier(li) {
    const ti   = this.tierOf(li);
    if (ti < 0) return null;
    const lvls = TIERS[ti].levels;
    const pos  = lvls.indexOf(li);
    // Busca el próximo nivel incompleto: primero los que vienen después, luego los anteriores
    for (let i = pos + 1; i < lvls.length; i++) {
      if (!this.completed.includes(lvls[i])) return lvls[i];
    }
    for (let i = 0; i < pos; i++) {
      if (!this.completed.includes(lvls[i])) return lvls[i];
    }
    return null; // todos completados → tier terminado
  },
};

// ─── Persistencia de ajustes ──────────────────────────────────────────────────

const settings = {
  vol: parseFloat(localStorage.getItem('cc_vol') ?? '0.7'),
  sfx: localStorage.getItem('cc_sfx') !== 'false',
  save() {
    localStorage.setItem('cc_vol', this.vol);
    localStorage.setItem('cc_sfx', this.sfx);
  },
};

// ─── Musica (archivo www/audio/music.mp3) ────────────────────────────────────

const music = (() => {
  let el = null;
  function getEl() {
    if (!el) el = document.getElementById('bgMusic');
    return el;
  }
  function applyVol() { const a = getEl(); if (a) a.volume = settings.vol; }

  return {
    tryAutoStart() {
      const a = getEl(); if (!a) return;
      a.volume = settings.vol;
      a.play().catch(() => {});
    },
    toggle() {
      const a = getEl(); if (!a) return false;
      if (a.paused) {
        a.volume = settings.vol;
        a.play().catch(() => {});
        return true;
      } else {
        a.pause();
        return false;
      }
    },
    isActive() { const a = getEl(); return a ? !a.paused : false; },
    setVolume(v) { settings.vol = v; applyVol(); settings.save(); },
    duck() {
      const a = getEl(); if (!a) return;
      const from = a.volume, to = 0.13, t0 = performance.now(), dur = 1100;
      const go = () => { const p = Math.min(1,(performance.now()-t0)/dur); a.volume = from+(to-from)*p; if(p<1) requestAnimationFrame(go); };
      requestAnimationFrame(go);
    },
    restore() {
      const a = getEl(); if (!a) return;
      const from = a.volume, to = settings.vol, t0 = performance.now(), dur = 700;
      const go = () => { const p = Math.min(1,(performance.now()-t0)/dur); a.volume = from+(to-from)*p; if(p<1) requestAnimationFrame(go); };
      requestAnimationFrame(go);
    },
    syncBtn() {
      document.getElementById('btnMusic')
        .classList.toggle('music-on', this.isActive());
    },
  };
})();

// ─── Sonidos de win / lose (Web Audio API) ───────────────────────────────────

function playWinSfx() {
  if (!settings.sfx) return;
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    [[523.25, 0], [659.25, 0.11], [783.99, 0.22], [1046.5, 0.33]].forEach(([f, t]) => {
      const osc = ac.createOscillator(), g = ac.createGain();
      osc.type = 'sine'; osc.frequency.value = f;
      g.gain.setValueAtTime(0, ac.currentTime + t);
      g.gain.linearRampToValueAtTime(0.22, ac.currentTime + t + 0.04);
      g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + t + 0.52);
      osc.connect(g); g.connect(ac.destination);
      osc.start(ac.currentTime + t); osc.stop(ac.currentTime + t + 0.6);
    });
  } catch(e) {}
}

function playLoseSfx() {
  if (!settings.sfx) return;
  try {
    const ac = new (window.AudioContext || window.webkitAudioContext)();
    [[330, 0], [277.18, 0.18], [220, 0.36]].forEach(([f, t]) => {
      const osc = ac.createOscillator(), g = ac.createGain();
      osc.type = 'sawtooth'; osc.frequency.value = f;
      g.gain.setValueAtTime(0.16, ac.currentTime + t);
      g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + t + 0.44);
      osc.connect(g); g.connect(ac.destination);
      osc.start(ac.currentTime + t); osc.stop(ac.currentTime + t + 0.5);
    });
  } catch(e) {}
}

// ─── Game logic ───────────────────────────────────────────────────────────────

class Game {
  constructor(levelIndex) {
    this.levelIndex    = levelIndex;
    this.level         = LEVELS[levelIndex];
    this.gridSize      = this.level.grid;
    this.paths         = {};
    this.occupied      = {};
    this.activeColor   = null;
    this.status        = 'playing';
    this.secondsLeft   = TIMER_SECONDS;
    this.timerInterval = null;
    this.hintUsed      = false;
    this._initPaths();
    this._startTimer();
  }

  _initPaths() {
    this.level.dots.forEach(d => { if (!this.paths[d.color]) this.paths[d.color] = []; });
  }

  _startTimer() {
    this.timerInterval = setInterval(() => {
      if (this.status !== 'playing') { clearInterval(this.timerInterval); return; }
      if (--this.secondsLeft <= 0) {
        this.secondsLeft = 0;
        this.status = 'lost';
        clearInterval(this.timerInterval);
        onGameEnd('lost');
      }
      renderTimer(this.secondsLeft);
    }, 1000);
  }

  _dotAt(row, col) { return this.level.dots.find(d => d.row === row && d.col === col) || null; }
  _key(row, col)   { return `${row},${col}`; }

  _rebuildOccupied() {
    this.occupied = {};
    for (const [color, pts] of Object.entries(this.paths))
      pts.forEach(p => { this.occupied[this._key(p.row, p.col)] = color; });
  }

  startDrag(row, col) {
    if (this.status !== 'playing') return;
    const dot = this._dotAt(row, col);
    if (!dot) return;
    this.paths[dot.color] = [{ row, col }];
    this._rebuildOccupied();
    this.activeColor = dot.color;
  }

  moveDrag(row, col) {
    if (this.status !== 'playing' || !this.activeColor) return;
    const path = this.paths[this.activeColor];
    if (!path || path.length === 0) return;

    const last = path[path.length - 1];
    if (last.row === row && last.col === col) return;

    if (path.length >= 2) {
      const prev = path[path.length - 2];
      if (prev.row === row && prev.col === col) {
        path.pop();
        this._rebuildOccupied();
        return;
      }
    }

    const dr = Math.abs(row - last.row), dc = Math.abs(col - last.col);
    if (!((dr === 1 && dc === 0) || (dr === 0 && dc === 1))) return;

    const occupant = this.occupied[this._key(row, col)];
    if (occupant && occupant !== this.activeColor) return;

    const dot = this._dotAt(row, col);
    if (dot && dot.color === this.activeColor && path.length > 1) {
      path.push({ row, col });
      this._rebuildOccupied();
      this.activeColor = null;
      this._checkWin();
      return;
    }

    path.push({ row, col });
    this._rebuildOccupied();
  }

  endDrag() { this.activeColor = null; this._checkWin(); }

  _checkWin() {
    const colorSet = [...new Set(this.level.dots.map(d => d.color))];
    const allConnected = colorSet.every(color => {
      const path = this.paths[color];
      if (!path || path.length < 2) return false;
      const [a, b] = this.level.dots.filter(d => d.color === color);
      const s = path[0], e = path[path.length - 1];
      return (s.row===a.row && s.col===a.col && e.row===b.row && e.col===b.col)
          || (s.row===b.row && s.col===b.col && e.row===a.row && e.col===a.col);
    });
    if (allConnected && Object.keys(this.occupied).length === this.gridSize * this.gridSize) {
      this.status = 'won';
      clearInterval(this.timerInterval);
      onGameEnd('won');
    }
  }

  applyHint() {
    if (this.hintUsed || this.status !== 'playing') return false;
    const hc  = this.level.hintColor;
    const sol = this.level.solution && this.level.solution[hc];
    if (!sol) return false;
    const cells = new Set(sol.map(p => `${p.row},${p.col}`));
    for (const color of Object.keys(this.paths)) {
      if (color !== hc && this.paths[color].some(p => cells.has(`${p.row},${p.col}`)))
        this.paths[color] = [];
    }
    this.paths[hc] = sol.map(p => ({ row: p.row, col: p.col }));
    this._rebuildOccupied();
    this.hintUsed = true;
    this._checkWin();
    return true;
  }

  fillCount()      { return Object.keys(this.occupied).length; }
  totalCells()     { return this.gridSize * this.gridSize; }
  totalColors()    { return new Set(this.level.dots.map(d => d.color)).size; }
  connectedCount() {
    const colorSet = [...new Set(this.level.dots.map(d => d.color))];
    return colorSet.filter(color => {
      const path = this.paths[color];
      if (!path || path.length < 2) return false;
      const [a, b] = this.level.dots.filter(d => d.color === color);
      const s = path[0], e = path[path.length - 1];
      return (s.row===a.row && s.col===a.col && e.row===b.row && e.col===b.col)
          || (s.row===b.row && s.col===b.col && e.row===a.row && e.col===a.col);
    }).length;
  }

  destroy() { clearInterval(this.timerInterval); }
}

// ─── Renderer ────────────────────────────────────────────────────────────────

let canvas, ctx, game, cellSize;
let gameAnimId = null;
let gameTime   = 0;
let completionRings    = [];   // [{x,y,color,birth}] — efecto al conectar un par
let prevConnectedCount = 0;    // detecta nuevas conexiones cada frame

function initCanvas() {
  canvas = document.getElementById('gameCanvas');
  ctx    = canvas.getContext('2d');
  resizeCanvas();
  window.addEventListener('resize', () => { resizeCanvas(); render(); });
}

function resizeCanvas() {
  const container = document.getElementById('canvasContainer');
  const size = Math.max(
    Math.min(container.clientWidth - 20, container.clientHeight - 4, 460),
    140
  );
  canvas.width  = size;
  canvas.height = size;
  if (game) cellSize = size / game.gridSize;
}

// Devuelve el set de colores que ya tienen sus dos extremos conectados
function getConnectedColors() {
  const colors = [...new Set(game.level.dots.map(d => d.color))];
  return new Set(colors.filter(color => {
    const path = game.paths[color];
    if (!path || path.length < 2) return false;
    const [a, b] = game.level.dots.filter(d => d.color === color);
    const s = path[0], e = path[path.length - 1];
    return (s.row===a.row && s.col===a.col && e.row===b.row && e.col===b.col)
        || (s.row===b.row && s.col===b.col && e.row===a.row && e.col===a.col);
  }));
}

function render() {
  if (!game) return;

  // Detectar colores recién conectados y lanzar efecto de onda
  const connected = getConnectedColors();
  if (connected.size > prevConnectedCount) {
    connected.forEach(color => {
      // Solo dispara para colores nuevamente completados
      const alreadyHasRing = completionRings.some(r => r.color === color && gameTime - r.birth < 0.1);
      if (!alreadyHasRing) {
        game.level.dots.filter(d => d.color === color).forEach(dot => {
          completionRings.push({
            x: dot.col * cellSize + cellSize / 2,
            y: dot.row * cellSize + cellSize / 2,
            color, birth: gameTime,
          });
        });
      }
    });
  }
  prevConnectedCount = connected.size;

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  drawPaths();
  drawCompletionRings();
  drawDots(connected);
  updateHintBar();
}

// Ondas expansivas al conectar un par de puntos
function drawCompletionRings() {
  const gm = getDifficultyTheme().glow;
  completionRings = completionRings.filter(ring => {
    const age      = gameTime - ring.birth;
    const duration = 1.4;
    if (age > duration) return false;

    const c        = COLORS[ring.color];
    const progress = age / duration;
    const radius   = cellSize * 0.32 * (1 + progress * 2.2);
    const alpha    = (1 - progress) * 0.75;
    const lw       = cellSize * 0.09 * (1 - progress * 0.7);

    ctx.beginPath();
    ctx.arc(ring.x, ring.y, radius, 0, Math.PI * 2);
    ctx.strokeStyle  = c.glow;
    ctx.lineWidth    = lw;
    ctx.globalAlpha  = alpha;
    ctx.shadowColor  = c.glow;
    ctx.shadowBlur   = cellSize * 0.4 * gm * (1 - progress);
    ctx.stroke();

    ctx.shadowBlur  = 0;
    ctx.globalAlpha = 1;
    return true;
  });
}

function cellRoundRect(x, y, s, r) {
  ctx.beginPath();
  if (ctx.roundRect) {
    ctx.roundRect(x, y, s, s, r);
  } else {
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + s - r, y);
    ctx.quadraticCurveTo(x + s, y, x + s, y + r);
    ctx.lineTo(x + s, y + s - r);
    ctx.quadraticCurveTo(x + s, y + s, x + s - r, y + s);
    ctx.lineTo(x + r, y + s);
    ctx.quadraticCurveTo(x, y + s, x, y + s - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
  }
}

function getDifficultyTheme() {
  const d = game && game.level ? game.level.difficulty : 'easy';
  return DIFF_THEMES[d] || DIFF_THEMES.easy;
}

function applyDifficultyTheme(difficulty) {
  const theme  = DIFF_THEMES[difficulty] || DIFF_THEMES.easy;
  const screen = document.getElementById('screen-game');
  const header = document.querySelector('.game-header');
  screen.style.background = theme.bg;
  canvas.style.background  = theme.bg;
  const gradMap = {
    easy:   'linear-gradient(135deg,#1E88E5 0%,#1565C0 55%,#0D47A1 100%)',
    medium: 'linear-gradient(135deg,#3949AB 0%,#283593 55%,#1A237E 100%)',
    hard:   'linear-gradient(135deg,#8E24AA 0%,#6A1B9A 55%,#4A148C 100%)',
    expert: 'linear-gradient(135deg,#37474F 0%,#212121 55%,#0a0a0a 100%)',
  };
  header.style.background = gradMap[difficulty] || gradMap.easy;
}

function drawGrid() {
  const theme = getDifficultyTheme();
  const n     = game.gridSize;
  const pad   = Math.max(1.5, cellSize * 0.04);
  const r     = cellSize * 0.16;
  const s     = cellSize - pad * 2;

  // Fondo del canvas con el color del tema
  ctx.fillStyle = theme.bg;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  for (let row = 0; row < n; row++) {
    for (let col = 0; col < n; col++) {
      const even = (row + col) % 2 === 0;
      cellRoundRect(col * cellSize + pad, row * cellSize + pad, s, r);
      ctx.fillStyle = even ? theme.cell : theme.cellAlt;
      ctx.fill();
      // Borde interior sutil — efecto de profundidad
      ctx.strokeStyle = 'rgba(255,255,255,0.05)';
      ctx.lineWidth   = 0.5;
      ctx.stroke();
    }
  }

  // Nodos de intersección estilo motor de videojuego
  ctx.fillStyle = 'rgba(255,255,255,0.09)';
  for (let ri = 0; ri <= n; ri++) {
    for (let ci = 0; ci <= n; ci++) {
      ctx.beginPath();
      ctx.arc(ci * cellSize, ri * cellSize, Math.max(1.5, cellSize * 0.028), 0, Math.PI * 2);
      ctx.fill();
    }
  }
}

// Catmull-Rom → Bezier para esquinas redondeadas orgánicas
function drawSmoothedPath(points) {
  if (points.length < 2) return;
  const n = points.length;
  ctx.beginPath();
  ctx.moveTo(points[0].x, points[0].y);
  if (n === 2) {
    ctx.lineTo(points[1].x, points[1].y);
  } else {
    for (let i = 0; i < n - 1; i++) {
      const p0 = points[Math.max(0, i - 1)];
      const p1 = points[i];
      const p2 = points[i + 1];
      const p3 = points[Math.min(n - 1, i + 2)];
      const cp1x = p1.x + (p2.x - p0.x) / 6;
      const cp1y = p1.y + (p2.y - p0.y) / 6;
      const cp2x = p2.x - (p3.x - p1.x) / 6;
      const cp2y = p2.y - (p3.y - p1.y) / 6;
      ctx.bezierCurveTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y);
    }
  }
  ctx.stroke();
}

// Cuatro capas: glow difuso → halo medio → tubo sólido → núcleo brillante
function drawPaths() {
  const gm = getDifficultyTheme().glow;

  for (const [color, pts] of Object.entries(game.paths)) {
    if (pts.length < 2) continue;
    const c = COLORS[color];
    const points = pts.map(p => ({
      x: p.col * cellSize + cellSize / 2,
      y: p.row * cellSize + cellSize / 2,
    }));

    ctx.lineCap  = 'round';
    ctx.lineJoin = 'round';

    // Capa 1 — glow exterior (más contenido)
    ctx.shadowColor  = c.glow;
    ctx.shadowBlur   = cellSize * 0.72 * gm;
    ctx.strokeStyle  = c.fill;
    ctx.lineWidth    = cellSize * 0.48;
    ctx.globalAlpha  = Math.min(0.22, 0.14 * gm);
    drawSmoothedPath(points);

    // Capa 2 — halo medio
    ctx.shadowBlur   = cellSize * 0.36 * gm;
    ctx.lineWidth    = cellSize * 0.43;
    ctx.globalAlpha  = 0.62;
    drawSmoothedPath(points);

    // Capa 3 — tubo principal sólido
    ctx.shadowBlur   = cellSize * 0.14 * gm;
    ctx.lineWidth    = cellSize * 0.36;
    ctx.globalAlpha  = 1;
    drawSmoothedPath(points);

    // Capa 4 — núcleo brillante central (sin sombra)
    ctx.shadowBlur   = 0;
    ctx.shadowColor  = 'transparent';
    ctx.strokeStyle  = 'rgba(255,255,255,0.40)';
    ctx.lineWidth    = cellSize * 0.10;
    drawSmoothedPath(points);
  }

  ctx.shadowBlur  = 0;
  ctx.shadowColor = 'transparent';
  ctx.globalAlpha = 1;
}

function drawDots(connectedColors) {
  const gm    = getDifficultyTheme().glow;
  const pulse = Math.sin(gameTime * 1.8) * 0.5 + 0.5; // 0..1

  game.level.dots.forEach(dot => {
    const c           = COLORS[dot.color];
    const x           = dot.col * cellSize + cellSize / 2;
    const y           = dot.row * cellSize + cellSize / 2;
    const r           = cellSize * 0.30;
    const isConnected = connectedColors && connectedColors.has(dot.color);

    // Aura exterior pulsante — más pequeña y sutil
    ctx.beginPath();
    ctx.arc(x, y, r + cellSize * (0.07 + pulse * 0.04), 0, Math.PI * 2);
    ctx.fillStyle   = c.glow;
    ctx.globalAlpha = (0.06 + pulse * 0.06) * gm;
    ctx.fill();
    ctx.globalAlpha = 1;

    // Sombra glow
    ctx.shadowColor = c.glow;
    ctx.shadowBlur  = cellSize * 0.42 * gm * (0.5 + pulse * 0.35);

    // Esfera 3D — gradiente radial descentrado
    const grad = ctx.createRadialGradient(
      x - r * 0.30, y - r * 0.30, r * 0.04,
      x, y, r
    );
    grad.addColorStop(0,    c.light);
    grad.addColorStop(0.42, c.fill);
    grad.addColorStop(1,    c.dark);

    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fillStyle = grad;
    ctx.fill();

    ctx.shadowBlur  = 0;
    ctx.shadowColor = 'transparent';

    // Anillo de "conectado" — indica que el par está unido
    if (isConnected) {
      ctx.beginPath();
      ctx.arc(x, y, r + cellSize * 0.07, 0, Math.PI * 2);
      ctx.strokeStyle = c.light;
      ctx.lineWidth   = cellSize * 0.035;
      ctx.globalAlpha = 0.70 + pulse * 0.25;
      ctx.shadowColor = c.glow;
      ctx.shadowBlur  = cellSize * 0.25 * gm;
      ctx.stroke();
      ctx.shadowBlur  = 0;
      ctx.globalAlpha = 1;
    }

    // Reflejo especular
    ctx.beginPath();
    ctx.arc(x - r * 0.28, y - r * 0.28, r * 0.22, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.68)';
    ctx.fill();

    // Rim light
    ctx.beginPath();
    ctx.arc(x + r * 0.26, y + r * 0.26, r * 0.13, 0, Math.PI * 2);
    ctx.fillStyle = 'rgba(255,255,255,0.18)';
    ctx.fill();
  });

  ctx.globalAlpha = 1;
  ctx.shadowBlur  = 0;
}

function updateHintBar() {
  const el = document.getElementById('hint');
  if (!el || !game) return;
  const pct = Math.floor(game.fillCount() / game.totalCells() * 100);
  el.textContent = `Conectados: ${game.connectedCount()}/${game.totalColors()}  ·  Tablero: ${pct}%`;
}

// ─── Input — Pointer Events + RAF + interpolacion ────────────────────────────

function getCell(clientX, clientY) {
  const rect  = canvas.getBoundingClientRect();
  const scaleX = canvas.width  / rect.width;
  const scaleY = canvas.height / rect.height;
  const col = Math.floor(((clientX - rect.left) * scaleX) / cellSize);
  const row = Math.floor(((clientY - rect.top)  * scaleY) / cellSize);
  if (row < 0 || row >= game.gridSize || col < 0 || col >= game.gridSize) return null;
  return { row, col };
}

function interpolateCells(from, to) {
  const cells = [];
  let r = from.row, c = from.col;
  const dr = Math.sign(to.row - r), dc = Math.sign(to.col - c);
  while (r !== to.row) { r += dr; cells.push({ row: r, col: c }); }
  while (c !== to.col) { c += dc; cells.push({ row: r, col: c }); }
  return cells;
}

function attachInput() {
  let lastCell   = null;
  let rafPending = false;

  function scheduleRender() {
    if (!rafPending) {
      rafPending = true;
      requestAnimationFrame(() => { rafPending = false; render(); });
    }
  }

  function onDown(e) {
    e.preventDefault();
    canvas.setPointerCapture(e.pointerId);
    const cell = getCell(e.clientX, e.clientY);
    if (!cell) return;
    lastCell = cell;
    game.startDrag(cell.row, cell.col);
    scheduleRender();
  }

  function onMove(e) {
    if (!game.activeColor) return;
    const cell = getCell(e.clientX, e.clientY);
    if (!cell) return;
    if (lastCell) {
      const dist = Math.abs(cell.row - lastCell.row) + Math.abs(cell.col - lastCell.col);
      if (dist > 1) {
        interpolateCells(lastCell, cell).forEach(c => game.moveDrag(c.row, c.col));
      } else if (dist > 0) {
        game.moveDrag(cell.row, cell.col);
      }
    } else {
      game.moveDrag(cell.row, cell.col);
    }
    lastCell = cell;
    scheduleRender();
  }

  function onUp() {
    lastCell = null;
    game.endDrag();
    scheduleRender();
  }

  canvas.addEventListener('pointerdown',   onDown);
  canvas.addEventListener('pointermove',   onMove);
  canvas.addEventListener('pointerup',     onUp);
  canvas.addEventListener('pointercancel', onUp);
}

// ─── Game lifecycle ───────────────────────────────────────────────────────────

function renderTimer(seconds) {
  const el = document.getElementById('timer');
  if (!el) return;
  const m = String(Math.floor(seconds / 60)).padStart(2, '0');
  const s = String(seconds % 60).padStart(2, '0');
  el.textContent = `${m}:${s}`;
  el.className   = `timer-box${seconds <= 30 ? ' urgent' : ''}`;
}

function onGameEnd(result) {
  render();
  if (result === 'won') { playWinSfx(); progress.markDone(game.levelIndex); updateContinuarBtn(); }
  else                    playLoseSfx();
  setTimeout(() => showModal(result), 320);
}

function showModal(result) {
  const modal    = document.getElementById('modal');
  const nextBtn  = document.getElementById('btnModalNext');
  const homeBtn  = document.getElementById('btnModalHome');
  const icon     = document.getElementById('modalIcon');

  if (result === 'won') {
    icon.textContent = '★';
    icon.className   = 'modal-icon win';
    document.getElementById('modalTitle').textContent = 'Ganaste';
    document.getElementById('modalMsg').textContent   = 'Conectaste todos los puntos';
  } else {
    icon.textContent = '○';
    icon.className   = 'modal-icon lose';
    document.getElementById('modalTitle').textContent = 'Tiempo';
    document.getElementById('modalMsg').textContent   = 'Se acabo el tiempo. Intentalo de nuevo';
  }

  if (result === 'won' && game) {
    const ti          = TIERS.findIndex(t => t.levels.includes(game.levelIndex));
    const nextInTier  = progress.nextInTier(game.levelIndex); // null = tier completado
    const hasNextTier = ti >= 0 && ti < TIERS.length - 1;

    if (nextInTier !== null) {
      // Quedan niveles en el tier actual
      nextBtn.textContent    = 'Siguiente nivel';
      nextBtn.dataset.action = 'same';
      nextBtn.dataset.target = String(nextInTier);
      nextBtn.classList.remove('hidden');
      homeBtn.classList.add('hidden');
    } else if (hasNextTier) {
      // Tier completado → avanzar al siguiente modo
      nextBtn.textContent    = 'Siguiente nivel';
      nextBtn.dataset.action = 'nexttier';
      nextBtn.dataset.target = String(ti + 1);
      nextBtn.classList.remove('hidden');
      homeBtn.classList.add('hidden');
    } else {
      // Muy Difícil completado → volver al inicio
      nextBtn.classList.add('hidden');
      homeBtn.textContent  = 'Menu principal';
      homeBtn.dataset.dest = 'home';
      homeBtn.classList.remove('hidden');
    }
  } else {
    // Derrota
    nextBtn.classList.add('hidden');
    homeBtn.textContent  = 'Inicio';
    homeBtn.dataset.dest = 'levels';
    homeBtn.classList.remove('hidden');
  }

  modal.classList.remove('hidden');
  const card = modal.querySelector('.modal-card');
  card.style.animation = 'none';
  requestAnimationFrame(() => {
    card.style.animation = 'modalIn .38s cubic-bezier(.34,1.56,.64,1) both';
  });
}

function hideModal() { document.getElementById('modal').classList.add('hidden'); }

function updateHintButton() {
  const btn   = document.getElementById('btnHint');
  const badge = document.getElementById('hintBadge');
  if (!game) return;
  btn.disabled      = game.hintUsed;
  badge.textContent = game.hintUsed ? 'x0' : 'x1';
}

function getLevelTitle(li) {
  const ti = TIERS.findIndex(t => t.levels.includes(li));
  if (ti < 0) return LEVELS[li]?.title || 'Nivel';
  const done = TIERS[ti].levels.filter(l => progress.completed.includes(l)).length;
  return `${TIERS[ti].label} · ${done + 1}/${TIERS[ti].levels.length}`;
}

function updateContinuarBtn() {
  const stored = localStorage.getItem('cc_completed');
  const has    = stored && JSON.parse(stored).length > 0;
  document.getElementById('btnContinuar').classList.toggle('hidden', !has);
}

function startGameLoop() {
  stopGameLoop();
  (function loop() {
    gameTime += 0.04;
    render();
    gameAnimId = requestAnimationFrame(loop);
  })();
}

function stopGameLoop() {
  if (gameAnimId !== null) {
    cancelAnimationFrame(gameAnimId);
    gameAnimId = null;
  }
}

function startLevel(index) {
  if (game) game.destroy();
  game = new Game(index);
  document.getElementById('levelTitle').textContent = getLevelTitle(index);
  hideModal();
  showScreen('game');
  resizeCanvas();
  applyDifficultyTheme(game.level.difficulty);
  gameTime          = 0;
  completionRings   = [];
  prevConnectedCount = 0;
  renderTimer(TIMER_SECONDS);
  updateHintButton();
  startGameLoop();
  music.duck();
  music.syncBtn();
}

function resetLevel() { startLevel(game.levelIndex); }

function showScreen(name) {
  const el = document.getElementById(`screen-${name}`);
  document.querySelectorAll('.screen').forEach(s => {
    s.classList.add('hidden');
    s.classList.remove('anim-fadein', 'anim-dissolve');
  });
  el.classList.remove('hidden');
  void el.offsetWidth;
  el.classList.add(name === 'game' ? 'anim-dissolve' : 'anim-fadein');
  if (name !== 'game') stopGameLoop();
  if (name === 'home' || name === 'levels') startBg(); else stopBg();
}

// ─── Ajustes modal ────────────────────────────────────────────────────────────

function openSettings() {
  const volEl = document.getElementById('settingsVol');
  const sfxEl = document.getElementById('settingsSfx');
  volEl.value          = Math.round(settings.vol * 100);
  sfxEl.dataset.on     = settings.sfx;
  sfxEl.textContent    = settings.sfx ? 'On' : 'Off';
  document.getElementById('modal-settings').classList.remove('hidden');
}

function closeSettings() {
  settings.save();
  document.getElementById('modal-settings').classList.add('hidden');
}

// ─── Gusanos de fondo ────────────────────────────────────────────────────────

const WORM_PALETTE = [
  [229,57,53],[30,136,229],[253,216,53],[67,160,71],[251,140,0],[156,39,176],[0,188,212]
];

class BgWorm {
  constructor(w, h) { this.spawn(w, h); }
  spawn(w, h) {
    this.x     = Math.random() * w;
    this.y     = Math.random() * h;
    this.angle = Math.random() * Math.PI * 2;
    this.speed = 0.4 + Math.random() * 0.4;
    this.turn  = (Math.random() - 0.5) * 0.035;
    const c    = WORM_PALETTE[Math.floor(Math.random() * WORM_PALETTE.length)];
    this.rgb   = c;
    this.segs  = Array.from({length: 28}, () => ({x: this.x, y: this.y}));
    this.rad   = 8 + Math.random() * 5;
    this.alpha = 0.20 + Math.random() * 0.08;
    this.dying = false;
    this.fade  = 1;
  }
  update(w, h) {
    if (this.dying) { this.fade -= 0.022; return this.fade > 0; }
    this.angle += this.turn + (Math.random() - 0.5) * 0.012;
    const nx = this.x + Math.cos(this.angle) * this.speed;
    const ny = this.y + Math.sin(this.angle) * this.speed;
    if (nx < 0 || nx > w) this.angle = Math.PI - this.angle;
    if (ny < 0 || ny > h) this.angle = -this.angle;
    this.x = Math.max(0, Math.min(w, nx));
    this.y = Math.max(0, Math.min(h, ny));
    this.segs.unshift({x: this.x, y: this.y});
    this.segs.pop();
    return true;
  }
  draw(ctx) {
    const base = this.alpha * this.fade;
    const n    = this.segs.length;
    ctx.lineCap = 'round';
    for (let i = 0; i < n - 1; i++) {
      const t = 1 - i / n;
      ctx.beginPath();
      ctx.moveTo(this.segs[i].x, this.segs[i].y);
      ctx.lineTo(this.segs[i + 1].x, this.segs[i + 1].y);
      ctx.strokeStyle = `rgba(${this.rgb[0]},${this.rgb[1]},${this.rgb[2]},${base * t})`;
      ctx.lineWidth   = this.rad * (0.3 + t * 0.7) * 2;
      ctx.stroke();
    }
  }
  hits(other) {
    const dx = this.x - other.x, dy = this.y - other.y;
    return dx*dx + dy*dy < (this.rad + other.rad + 4) ** 2;
  }
}

let bgCv, bgCt, bgWorms = [], bgOn = false;

function initBg() {
  bgCv = document.getElementById('bgCanvas');
  bgCt = bgCv.getContext('2d');
  const resize = () => { bgCv.width = window.innerWidth; bgCv.height = window.innerHeight; };
  window.addEventListener('resize', resize);
  resize();
  bgWorms = Array.from({length: 8}, () => new BgWorm(bgCv.width, bgCv.height));
}

function startBg() {
  if (bgOn) return;
  bgOn = true;
  (function frame() {
    if (!bgOn) return;
    const w = bgCv.width, h = bgCv.height;
    const g = bgCt.createLinearGradient(0, 0, w * 0.5, h);
    g.addColorStop(0, '#1565C0'); g.addColorStop(1, '#0D47A1');
    bgCt.fillStyle = g;
    bgCt.fillRect(0, 0, w, h);
    for (let i = 0; i < bgWorms.length; i++) {
      if (bgWorms[i].dying) continue;
      for (let j = i + 1; j < bgWorms.length; j++) {
        if (!bgWorms[j].dying && bgWorms[i].hits(bgWorms[j])) {
          bgWorms[i].dying = bgWorms[j].dying = true;
        }
      }
    }
    bgWorms = bgWorms.filter(wm => {
      const alive = wm.update(w, h);
      if (alive) wm.draw(bgCt);
      else setTimeout(() => { if (bgOn) bgWorms.push(new BgWorm(w, h)); }, 900 + Math.random() * 1400);
      return alive;
    });
    requestAnimationFrame(frame);
  })();
}

function stopBg() {
  bgOn = false;
  if (bgCt) bgCt.clearRect(0, 0, bgCv.width, bgCv.height);
}

// ─── Tier list ───────────────────────────────────────────────────────────────

const LOCK_SVG = `<svg width="18" height="22" viewBox="0 0 18 22" fill="none">
  <rect x="1" y="9" width="16" height="12" rx="3" fill="rgba(255,255,255,.45)"/>
  <path d="M4 9V6.5a5 5 0 0 1 10 0V9" stroke="rgba(255,255,255,.45)" stroke-width="2.2" stroke-linecap="round"/>
</svg>`;

function renderTierList() {
  const list = document.getElementById('levelList');
  list.innerHTML = '';

  TIERS.forEach((tier, ti) => {
    const unlocked = progress.isTierUnlocked(ti);
    const done     = tier.levels.filter(li => progress.completed.includes(li)).length;
    const total    = tier.levels.length;
    const complete = done === total;

    const card = document.createElement('button');
    card.className = 'tier-btn';
    card.style.animationDelay = `${ti * 0.09}s`;
    card.disabled = !unlocked;

    const statusHtml = complete
      ? `<span class="tier-status tier-complete">&#10003;</span>`
      : unlocked
        ? `<span class="tier-status tier-arrow">&#8250;</span>`
        : `<span class="tier-status tier-lock">${LOCK_SVG}</span>`;

    card.innerHTML = `
      <div class="tier-color-bar" style="background:${tier.color}"></div>
      <div class="tier-info">
        <span class="tier-label">${tier.label}</span>
        <span class="tier-sub">${done}/${total} nivel${total > 1 ? 'es' : ''} completado${done !== 1 ? 's' : ''}</span>
      </div>
      ${statusHtml}
    `;

    if (unlocked) {
      card.addEventListener('click', () => startLevel(progress.firstPlayable(ti)));
    }

    list.appendChild(card);
  });
}

// ─── Boot ─────────────────────────────────────────────────────────────────────

window.addEventListener('DOMContentLoaded', () => {
  initCanvas();
  attachInput();
  initBg();

  const vEl = document.getElementById('appVersion');
  if (vEl) vEl.textContent = 'v' + (typeof APP_VERSION !== 'undefined' ? APP_VERSION : '1.0.0');
  updateContinuarBtn();

  renderTierList();

  // Splash → logo → home
  const splash    = document.getElementById('screen-splash');
  const logoScr   = document.getElementById('screen-logo');

  setTimeout(() => {
    // 1. Fade out splash
    splash.classList.add('fade-out');

    setTimeout(() => {
      splash.classList.add('hidden');

      // 2. Fade in logo (forzar reflow para que la transición CSS arranque)
      requestAnimationFrame(() => requestAnimationFrame(() => {
        logoScr.classList.add('logo-visible');
      }));

      // 3. Fade out logo y mostrar home
      setTimeout(() => {
        logoScr.classList.remove('logo-visible');
        setTimeout(() => {
          logoScr.style.display = 'none';
          showScreen('home');
          music.tryAutoStart();
          music.syncBtn();
        }, 900);
      }, 2800);

    }, 520);
  }, 1900);

  // Navegacion home
  document.getElementById('btnNuevaPartida').addEventListener('click', () => {
    localStorage.removeItem('cc_completed');
    sessionStorage.clear();
    progress.completed = [];
    updateContinuarBtn();
    renderTierList();
    showScreen('levels');
  });
  document.getElementById('btnContinuar').addEventListener('click', () => {
    renderTierList();
    showScreen('levels');
  });
  document.getElementById('btnSettingsOpen').addEventListener('click', openSettings);

  // Navegacion niveles
  document.getElementById('btnLevelsBack').addEventListener('click', () => showScreen('home'));

  // Controles en juego
  document.getElementById('btnHome').addEventListener('click', () => {
    if (game) game.destroy();
    music.restore();
    renderTierList();
    showScreen('levels');
  });
  document.getElementById('btnReset').addEventListener('click', resetLevel);
  document.getElementById('btnMusic').addEventListener('click', () => {
    const on = music.toggle();
    document.getElementById('btnMusic').classList.toggle('music-on', on);
  });
  document.getElementById('btnHint').addEventListener('click', () => {
    if (!game) return;
    if (game.applyHint()) { updateHintButton(); render(); }
  });

  // Modal win/lose
  document.getElementById('btnModalHome').addEventListener('click', () => {
    const dest = document.getElementById('btnModalHome').dataset.dest || 'levels';
    if (game) game.destroy();
    hideModal();
    music.restore();
    if (dest === 'home') {
      showScreen('home');
    } else {
      renderTierList();
      showScreen('levels');
    }
  });
  document.getElementById('btnModalRetry').addEventListener('click', () => { hideModal(); resetLevel(); });
  document.getElementById('btnModalNext').addEventListener('click',  () => {
    if (!game) return;
    const btn    = document.getElementById('btnModalNext');
    const action = btn.dataset.action;
    const target = parseInt(btn.dataset.target);
    if (action === 'same') {
      startLevel(target);
    } else if (action === 'nexttier') {
      startLevel(progress.firstPlayable(target));
    }
  });

  // Modal ajustes
  document.getElementById('settingsVol').addEventListener('input', e => {
    music.setVolume(parseInt(e.target.value) / 100);
  });
  document.getElementById('settingsSfx').addEventListener('click', () => {
    settings.sfx = !settings.sfx;
    const btn = document.getElementById('settingsSfx');
    btn.dataset.on    = settings.sfx;
    btn.textContent   = settings.sfx ? 'On' : 'Off';
  });
  document.getElementById('btnSettingsClose').addEventListener('click', closeSettings);
});

function diffLabel(d) {
  return { easy: 'Facil', medium: 'Medio', hard: 'Dificil', expert: 'Experto' }[d] || d;
}
